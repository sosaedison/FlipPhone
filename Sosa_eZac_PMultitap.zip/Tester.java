public class Tester {

    public static void main (String args[]) {


        System.out.println((char)97);
    }


}
